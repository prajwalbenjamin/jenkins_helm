BSH-API-PROTOTYPE
-----------------

This project is used to automate the jenkins .
It consists various enpoints

![image](https://production.github.bshg.com/storage/user/3099/files/7789ab8d-83fc-430e-bd4f-4a7b3a505e85)

