from pydantic import BaseModel

class ControllerList(BaseModel):
    controllerurl:str
    jobname:str
