from fastapi import FastAPI, HTTPException, Depends
import subprocess

app = FastAPI(
        title="Master Blender API (B/S/H) - First prototype",
    description="**This app is for creating, deleting, listing and getting info about jenkins instances.**",
    version="0.0.1",

)



@app.post("/create_jenkins_instance")
async def create_jenkins_instance():
    try:
        # Run the shell command to create the Jenkins instance using Helm charts
        subprocess.check_output("helm install jenkins -n jenkins -f values.yaml jenkinsci/jenkins", shell=True)
    except subprocess.CalledProcessError as e:
        # If the shell command returns a non-zero exit code, raise an HTTPException with a 500 status code
        raise HTTPException(status_code=500, detail=f"Failed to create Jenkins instance: {e.output}")
    else:
        # If the command succeeds, return a success message
        return {"message": "Jenkins instance created successfully."}

@app.get("/pods/{namespace}")
async def list_pods(namespace: str):
    command = f"kubectl get pods -n {namespace}"
    result = subprocess.run(command, shell=True, capture_output=True, text=True)
    if result.returncode != 0:
        return {"error": result.stderr}
    else:
        return {"output": result.stdout}
    
@app.get("/pods/{namespace}/{pod}")
async def get_pod_details(namespace: str, pod: str):
    command = f"kubectl describe pod {pod} -n {namespace}"
    try:
        result = subprocess.run(command, shell=True, check=True, capture_output=True, text=True)
        return {"output": result.stdout}
    except subprocess.CalledProcessError as e:
        raise HTTPException(status_code=404, detail=str(e.stderr))
    
@app.delete("/delete_pod/{namespace}/{pod_name}")
async def delete_pod(namespace: str, pod_name: str):
    try:
        # Run the shell command to delete the specified pod
        subprocess.check_output(f"kubectl delete pod {pod_name} -n {namespace}", shell=True)
    except subprocess.CalledProcessError as e:
        # If the shell command returns a non-zero exit code, raise an HTTPException with a 500 status code
        raise HTTPException(status_code=500, detail=f"Failed to delete pod: {e.output}")
    else:
        # If the command succeeds, return a success message
        return {"message": f"Pod {pod_name} deleted successfully."}
    

